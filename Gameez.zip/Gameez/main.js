const cursor = document.querySelector('.cursor');
const holes = [...document.querySelectorAll('.hole')];
const scoreEl = document.querySelector('.score span');
let score = 0;
let lives = 3;
const livesEl = document.getElementById('lives');

const sound = new Audio("Assets/Videos/smash.mp3");

const gameOverScreen = document.getElementById('gameOverScreen');
const finalScoreEl = document.getElementById('finalScore');
const restartBtn = document.getElementById('restartBtn');

function resetGame() {
    score = 0;
    lives = 3;
    scoreEl.textContent = score;
    livesEl.textContent = lives;
    gameOverScreen.style.display = 'none'; // Hide the game over screen
    holes.forEach(hole => {
        while (hole.firstChild) {
            hole.removeChild(hole.firstChild);  // Clear any moles
        }
    });
    run();  // Start the game again
}

restartBtn.addEventListener('click', resetGame);  // Add the event listener

function run() {
    if (lives <= 0) {
        gameOverScreen.style.display = 'block';
        finalScoreEl.textContent = score;
        return;
    }

    const i = Math.floor(Math.random() * holes.length);
    const hole = holes[i];
    let timer = null;

    const img = document.createElement('img');
    img.classList.add('mole');
    img.src = 'Assets/images/mole.png';

    img.addEventListener('click', () => {
        score += 10;
        sound.play();
        scoreEl.textContent = score;
        img.src = 'Assets/images/mole-whacked.png';
        clearTimeout(timer);
        setTimeout(() => {
            hole.removeChild(img);
            run();
        }, 500);
    });

    hole.appendChild(img);

    timer = setTimeout(() => {
        if (hole.contains(img)) {
            hole.removeChild(img);
            lives--;
            livesEl.textContent = lives;

            if (lives <= 0) {
                gameOverScreen.style.display = 'block';
                finalScoreEl.textContent = score;
                return;
            }
        }
        run();
    }, 1500);
}

run();

window.addEventListener('mousemove', e => {
    cursor.style.top = e.pageY + 'px';
    cursor.style.left = e.pageX + 'px';
});
window.addEventListener('mousedown', () => {
    cursor.classList.add('active');
});
window.addEventListener('mouseup', () => {
    cursor.classList.remove('active');
});