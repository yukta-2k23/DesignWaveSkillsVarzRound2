// Scroll animation + faster particles + sound FX coming next

const leaderboardData = [
  { rank: 1, name: "Alice", game: "Hangman", score: 120, badges: "🏆" },
  { rank: 2, name: "Bob", game: "Whack a Mole", score: 110, badges: "🥈" },
  { rank: 3, name: "Charlie", game: "Dots and Boxes", score: 100, badges: "🥉" },
  { rank: 4, name: "Dave", game: "Hangman", score: 90, badges: "" },
  { rank: 5, name: "Eve", game: "Whack a Mole", score: 85, badges: "" }
];

function populateLeaderboard(data) {
  const tbody = document.getElementById("leaderboardBody");
  tbody.innerHTML = "";
  data.forEach(player => {
    const row = document.createElement("tr");
    row.classList.add("reveal");
    row.innerHTML = `
      <td>${player.rank}</td>
      <td><img class="avatar" src="https://i.pravatar.cc/40?u=${player.name}" alt="avatar"/> ${player.name}</td>
      <td>${player.game}</td>
      <td>${player.score}</td>
      <td>${player.badges}</td>
    `;
    tbody.appendChild(row);
  });
  revealScroll();
}

populateLeaderboard(leaderboardData);

document.getElementById("searchInput").addEventListener("input", function(e) {
  const query = e.target.value.toLowerCase();
  const filtered = leaderboardData.filter(p => p.name.toLowerCase().includes(query));
  populateLeaderboard(filtered);
});

document.getElementById("gameFilter").addEventListener("change", function(e) {
  const game = e.target.value;
  if (game === "All") {
    populateLeaderboard(leaderboardData);
  } else {
    const filtered = leaderboardData.filter(p => p.game === game);
    populateLeaderboard(filtered);
  }
});

// Faster particles
particlesJS("particles", {
  particles: {
    number: { value: 40 },
    color: { value: "#00ffe7" },
    shape: { type: "circle" },
    opacity: { value: 0.4 },
    size: { value: 3 },
    line_linked: {
      enable: true,
      distance: 120,
      color: "#00ffe7",
      opacity: 0.4,
      width: 1
    },
    move: { enable: true, speed: 2.5 }
  },
  interactivity: {
    events: {
      onhover: { enable: true, mode: "repulse" }
    },
    modes: {
      repulse: { distance: 80 }
    }
  },
  retina_detect: true
});

// Scroll reveal effect
function revealScroll() {
  const reveals = document.querySelectorAll(".reveal");
  const options = {
    threshold: 0.1
  };
  const observer = new IntersectionObserver(function(entries, observer) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
        // sound on reveal
        const audio = new Audio("https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3");
        audio.volume = 0.2;
        audio.play();
      }
    });
  }, options);
  reveals.forEach(reveal => {
    observer.observe(reveal);
  });
}

window.addEventListener("scroll", revealScroll);