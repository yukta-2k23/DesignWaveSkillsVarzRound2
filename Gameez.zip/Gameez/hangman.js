//Initial References
const letterContainer = document.getElementById("letter-container");
const optionsContainer = document.getElementById("options-container");
const userInputSection = document.getElementById("user-input-section");
const newGameContainer = document.getElementById("new-game-container");
const newGameButton = document.getElementById("new-game-button");
const canvas = document.getElementById("canvas");
const resultText = document.getElementById("result-text");
const hintDisplay = document.getElementById("hint");



let options = {
  fruits: [
    { word: "Apple", hint: "A round, edible fruit with a red, green, or yellow skin." },
    { word: "Blueberry", hint: "Small, round, blue or purple berries, often used in muffins." },
    { word: "Mandarin", hint: "A small citrus fruit with a loose skin, easy to peel." },
    { word: "Pineapple", hint: "A large tropical fruit with a spiky exterior and sweet, juicy flesh." },
    { word: "Pomegranate", hint: "A fruit with a tough, red skin and many seeds inside." },
    { word: "Watermelon", hint: "A large, green fruit with a red, juicy interior, often eaten in summer." },
    { word: "Banana", hint: "A long, curved fruit that grows in bunches and is typically yellow when ripe." },
    { word: "Orange", hint: "A citrus fruit known for its high vitamin C content." },
    { word: "Strawberry", hint: "A small, red, heart-shaped fruit with seeds on its surface." },
    { word: "Grape", hint: "A small, round or oval fruit that grows in clusters on vines." },
    { word: "Mango", hint: "A tropical fruit with a sweet, fragrant, yellow-orange flesh." },
    { word: "Kiwi", hint: "A small, oval fruit with a fuzzy brown skin and green flesh with black seeds." },
  ],
  animals: [
    { word: "Hedgehog", hint: "A small mammal with a coat of stiff spines on its back." },
    { word: "Rhinoceros", hint: "A large, herbivorous mammal with one or two horns on its snout." },
    { word: "Squirrel", hint: "A small rodent with a bushy tail, often seen climbing trees." },
    { word: "Panther", hint: "A large, black or dark-colored cat, a member of the big cat family." },
    { word: "Walrus", hint: "A large marine mammal with tusks, flippers, and a thick layer of blubber." },
    { word: "Zebra", hint: "An African equine with black and white stripes." },
    { word: "Elephant", hint: "The largest living land animal, known for its trunk and tusks." },
    { word: "Giraffe", hint: "A tall African mammal with a very long neck." },
    { word: "Kangaroo", hint: "An Australian marsupial known for its powerful hind legs and pouch." },
    { word: "Dolphin", hint: "A highly intelligent marine mammal known for its playful behavior." },
    { word: "Chameleon", hint: "A lizard that can change color to blend in with its surroundings." },
    { word: "Ostrich", hint: "The largest living bird, known for its long neck and inability to fly." },
    { word: "Penguin", hint: "A flightless bird that lives in the Southern Hemisphere and is adapted for swimming." },
    { word: "Crocodile", hint: "A large, semi-aquatic reptile with a long body, powerful jaws, and sharp teeth." },
  ],
  countries: [
    { word: "India", hint: "A large country in South Asia known for its diverse culture and cuisine." },
    { word: "Hungary", hint: "A landlocked country in Central Europe with a rich history and thermal baths." },
    { word: "Kyrgyzstan", hint: "A landlocked country in Central Asia known for its mountainous terrain." },
    { word: "Switzerland", hint: "A landlocked country in the Alps known for its neutrality and chocolate." },
    { word: "Zimbabwe", hint: "A landlocked country in southern Africa known for its Victoria Falls." },
    { word: "Dominica", hint: "A Caribbean island nation known for its natural beauty and rainforests." },
    { word: "Brazil", hint: "The largest country in South America, famous for its Amazon rainforest and Carnival." },
    { word: "Japan", hint: "An island nation in East Asia known for its technology and culture." },
    { word: "Canada", hint: "The second-largest country in the world, known for its vast wilderness." },
    { word: "Australia", hint: "A country and continent in the Southern Hemisphere, known for its unique wildlife." },
    { word: "Mexico", hint: "A country in North America known for its ancient ruins and vibrant culture." },
    { word: "Egypt", hint: "A country in North Africa known for its pyramids and ancient civilization." },
    { word: "Argentina", hint: "A country in South America known for its tango dance and football." },
    { word: "Thailand", hint: "A Southeast Asian country known for its beaches and temples." },
  ],
  colors: [
    { word: "Red", hint: "The color of blood or a ripe tomato." },
    { word: "Blue", hint: "The color of the sky on a clear day." },
    { word: "Green", hint: "The color of grass and leaves." },
    { word: "Yellow", hint: "The color of the sun and ripe bananas." },
    { word: "Orange", hint: "A color between yellow and red." },
    { word: "Purple", hint: "A color between blue and red." },
    { word: "Black", hint: "The absence of color." },
    { word: "White", hint: "The presence of all colors." },
    { word: "Gray", hint: "A color between black and white." },
    { word: "Brown", hint: "The color of earth or wood." },
    { word: "Pink", hint: "A pale shade of red." },
    { word: "Teal", hint: "A greenish-blue color." },
  ],
  sports: [
    { word: "Football", hint: "A team sport played with an oval ball, popular in the US." },
    { word: "Soccer", hint: "A team sport played with a round ball, popular worldwide." },
    { word: "Basketball", hint: "A team sport where players score points by shooting a ball through a hoop." },
    { word: "Tennis", hint: "A racket sport played by two players or two pairs." },
    { word: "Baseball", hint: "A bat-and-ball sport played between two teams of nine players." },
    { word: "Swimming", hint: "A water sport involving propelling oneself through the water." },
    { word: "Golf", hint: "A sport where players use clubs to hit a ball into a series of holes." },
    { word: "Hockey", hint: "A team sport played on ice, where players use sticks to hit a puck." },
    { word: "Cricket", hint: "A bat-and-ball game played between two teams of eleven players, popular in Commonwealth countries." },
    { word: "Volleyball", hint: "A team sport where players hit a ball over a net." },
    { word: "Badminton", hint: "A racket sport played with a shuttlecock." },
    { word: "Boxing", hint: "A combat sport where two opponents fight each other with their fists." },
  ],
  movies: [
    { word: "Inception", hint: "A Christopher Nolan film about a thief who steals corporate secrets through use of dream-sharing technology." },
    { word: "Avatar", hint: "A James Cameron film set on the lush alien world of Pandora." },
    { word: "Titanic", hint: "A James Cameron film about a doomed ocean liner." },
    { word: "Joker", hint: "A 2019 psychological thriller film directed by Todd Phillips, starring Joaquin Phoenix." },
    { word: "Parasite", hint: "A South Korean dark comedy thriller film directed by Bong Joon-ho." },
    { word: "Interstellar", hint: "A Christopher Nolan science fiction film about a group of astronauts who travel through a wormhole in search of a new home for humanity." },
    { word: "Avengers", hint: "A Marvel superhero film featuring a team of heroes." },
    { word: "Gladiator", hint: "A historical epic film directed by Ridley Scott, starring Russell Crowe." },
    { word: "Matrix", hint: "A science fiction action film about a computer hacker who learns that reality is actually a simulated reality called the Matrix." },
    { word: "Shrek", hint: "An animated comedy film about an ogre." },
  ],
  actors: [
    { word: "Leonardo", hint: "Known for Titanic and Inception." },
    { word: "Scarlett", hint: "Plays Black Widow in the Avengers." },
    { word: "TomCruise", hint: "Famous for Mission Impossible." },
    { word: "BradPitt", hint: "Starred in Fight Club and Ocean's Eleven." },
    { word: "MerylStreep", hint: "One of the most acclaimed actresses of all time." },
    { word: "RobertD Niro", hint: "Known for his roles in crime films like Goodfellas and Taxi Driver." },
    { word: "NicoleKidman", hint: "Starred in Moulin Rouge! and The Hours." },
    { word: "WillSmith", hint: "Known for his roles in action and comedy films like Men in Black and The Fresh Prince of Bel-Air." },
    { word: "AngelinaJolie", hint: "Starred in Lara Croft: Tomb Raider and Mr. & Mrs. Smith." },
    { word: "JohnnyDepp", hint: "Known for his role as Captain Jack Sparrow in Pirates of the Caribbean." },
  ],
  hollywood: [
    { word: "LosAngeles", hint: "The city where Hollywood is located." },
    { word: "WalkOfFame", hint: "A famous sidewalk with stars." },
    { word: "AcademyAward", hint: "The most prestigious film award." },
    { word: "GoldenGlobes", hint: "Awards presented by the Hollywood Foreign Press Association." },
    { word: "Blockbuster", hint: "A very successful movie." },
    { word: "Premiere", hint: "The first public showing of a movie." },
    { word: "Director", hint: "The person who oversees the making of a film." },
    { word: "Producer", hint: "The person who manages the financial and administrative aspects of a film." },
    { word: "Screenplay", hint: "The script of a movie." },
    { word: "Soundstage", hint: "A large building used for filming movie scenes." },
  ],
  bollywood: [
    { word: "Mumbai", hint: "The city where Bollywood is based." },
    { word: "Bollywood", hint: "Indian Hindi-language film industry" },
    { word: "AmitabhBachchan", hint: "The 'Shahenshah' of Bollywood." },
    { word: "ShahRukhKhan", hint: "Known as the 'King Khan' of Bollywood." },
    { word: "AishwaryaRai", hint: "A former Miss World and a leading Bollywood actress." },
    { word: "SalmanKhan", hint: "Known for his action and romantic roles in Bollywood." },
    { word: "Kajol", hint: "Known for her performances in Dilwale Dulhania Le Jayenge and Kabhi Khushi Kabhie Gham." },
    { word: "RanbirKapoor", hint: "A contemporary Bollywood star from the Kapoor family." },
    { word: "DeepikaPadukone", hint: "One of the highest-paid actresses in Bollywood." },
    { word: "FilmfareAwards", hint: "One of the most prominent film award ceremonies in Bollywood." },
  ],
  gk: [
    { word: "EiffelTower", hint: "A wrought-iron lattice tower on the Champ de Mars in Paris, France." },
    { word: "MountEverest", hint: "Earth's highest mountain above sea level, located in the Himalayas." },
    { word: "AmazonRiver", hint: "The largest river in the world by discharge volume of water, located in South America." },
    { word: "AlbertEinstein", hint: "A German-born theoretical physicist who developed the theory of relativity." },
    { word: "WilliamShakespeare", hint: "An English playwright and poet, widely regarded as the greatest writer in the English language." },
    { word: "StatueOfLiberty", hint: "A colossal neoclassical sculpture on Liberty Island in New York Harbor." },
    { word: "GreatWallOfChina", hint: "A series of fortifications made of stone, brick, and rammed earth, built along the historical northern borders of Ancient Chinese states." },
    { word: "PyramidsOfGiza", hint: "Ancient pyramid complex located on the outskirts of Cairo, Egypt." },
    { word: "LeonardoDaVinci", hint: "An Italian polymath of the Renaissance whose areas of interest included invention, painting, sculpting, architecture, science, music, etc." },
    { word: "NeilArmstrong", hint: "An American astronaut and the first person to walk on the Moon." },
  ],
  programming: [
    { word: "JavaScript", hint: "A high-level, interpreted programming language primarily used for front-end web development." },
    { word: "Python", hint: "A high-level, general-purpose programming language known for its readability." },
    { word: "Java", hint: "A high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible." },
    { word: "HTML", hint: "The standard markup language for documents designed to be displayed in a web browser." },
    { word: "CSS", hint: "A style sheet language used for describing the presentation of a document written in a markup language such as HTML." },
    { word: "Algorithm", hint: "A process or set of rules to be followed in calculations or other problem-solving operations." },
    { word: "Database", hint: "An organized collection of structured information, or data, typically stored electronically in a computer system." },
    { word: "Compiler", hint: "A computer program that translates computer code written in one programming language into another language." },
    { word: "Debugging", hint: "The process of finding and resolving bugs (defects or problems) within computer programs." },
    { word: "Variable", hint: "A storage location paired with an associated symbolic name, which contains some known or unknown quantity of information referred to as a value." },
  ],
};


//count
let winCount = 0;
let count = 0;

let chosenWord = "";

//Display option buttons
const displayOptions = () => {
  optionsContainer.innerHTML += `<h3>Please Select An Option</h3>`;
  let buttonCon = document.createElement("div");
  for (let value in options) {
    buttonCon.innerHTML += `<button class="options" onclick="generateWord('${value}')">${value}</button>`;
  }
  optionsContainer.appendChild(buttonCon);
};

//Block all the Buttons
const blocker = () => {
  let optionsButtons = document.querySelectorAll(".options");
  let letterButtons = document.querySelectorAll(".letters");
  //disable all options
  optionsButtons.forEach((button) => {
    button.disabled = true;
  });

  //disable all letters
  letterButtons.forEach((button) => {
    button.disabled.true;
  });
  newGameContainer.classList.remove("hide");
};



const generateWord = (optionValue) => {
  let optionsButtons = document.querySelectorAll(".options");
  optionsButtons.forEach((button) => {
    if (button.innerText.toLowerCase() === optionValue) {
      button.classList.add("active");
    }
    button.disabled = true;
  });

  letterContainer.classList.remove("hide");
  userInputSection.innerText = "";
  hintDisplay.innerText = ""; // Clear previous hint

  let optionArray = options[optionValue];
  let randomWordObject = optionArray[Math.floor(Math.random() * optionArray.length)];
  chosenWord = randomWordObject.word.toUpperCase();
  let hint = randomWordObject.hint;

  hintDisplay.innerText = "Hint: " + hint;
  //replace every letter with span containing dash
  let displayItem = chosenWord.replace(/./g, '<span class="dashes">_</span>');

  //Display each element as span
  userInputSection.innerHTML = displayItem;
};


//Initial Function (Called when page loads/user presses new game)
const initializer = () => {
  winCount = 0;
  count = 0;

  //Initially erase all content and hide letteres and new game button
  userInputSection.innerHTML = "";
  optionsContainer.innerHTML = "";
  letterContainer.classList.add("hide");
  newGameContainer.classList.add("hide");
  letterContainer.innerHTML = "";

  //For creating letter buttons
  for (let i = 65; i < 91; i++) {
    let button = document.createElement("button");
    button.classList.add("letters");
    //Number to ASCII[A-Z]
    button.innerText = String.fromCharCode(i);
    //character button click
    button.addEventListener("click", () => {
      let charArray = chosenWord.split("");
      let dashes = document.getElementsByClassName("dashes");
      //if array contains clciked value replace the matched dash with letter else dram on canvas
      if (charArray.includes(button.innerText)) {
        charArray.forEach((char, index) => {
          //if character in array is same as clicked button
          if (char === button.innerText) {
            //replace dash with letter
            dashes[index].innerText = char;
            //increment counter
            winCount += 1;
            //if winCount equals word lenfth
            if (winCount == charArray.length) {
              resultText.innerHTML = `<h2 class='win-msg'>You Win!!</h2><p>The word was <span>${chosenWord}</span></p>`;
              //block all buttons
              blocker();
            }
          }
        });
      } else {
        //lose count
        count += 1;
        //for drawing man
        drawMan(count);
        //Count==6 because head,body,left arm, right arm,left leg,right leg
        if (count == 6) {
          resultText.innerHTML = `<h2 class='lose-msg'>You Lose!!</h2><p>The word was <span>${chosenWord}</span></p>`;
          blocker();
        }
      }
      //disable clicked button
      button.disabled = true;
    });
    letterContainer.append(button);
  }

  displayOptions();
  //Call to canvasCreator (for clearing previous canvas and creating initial canvas)
  let { initialDrawing } = canvasCreator();
  //initialDrawing would draw the frame
  initialDrawing();
};

//Canvas
const canvasCreator = () => {
  let context = canvas.getContext("2d");
  context.beginPath();
  context.strokeStyle = "#000";
  context.lineWidth = 2;

  //For drawing lines
  const drawLine = (fromX, fromY, toX, toY) => {
    context.moveTo(fromX, fromY);
    context.lineTo(toX, toY);
    context.stroke();
  };

  const head = () => {
    context.beginPath();
    context.arc(70, 30, 10, 0, Math.PI * 2, true);
    context.stroke();
  };

  const body = () => {
    drawLine(70, 40, 70, 80);
  };

  const leftArm = () => {
    drawLine(70, 50, 50, 70);
  };

  const rightArm = () => {
    drawLine(70, 50, 90, 70);
  };

  const leftLeg = () => {
    drawLine(70, 80, 50, 110);
  };

  const rightLeg = () => {
    drawLine(70, 80, 90, 110);
  };

  //initial frame
  const initialDrawing = () => {
    //clear canvas
    context.clearRect(0, 0, context.canvas.width, context.canvas.height);
    //bottom line
    drawLine(10, 130, 130, 130);
    //left line
    drawLine(10, 10, 10, 131);
    //top line
    drawLine(10, 10, 70, 10);
    //small top line
    drawLine(70, 10, 70, 20);
  };

  return { initialDrawing, head, body, leftArm, rightArm, leftLeg, rightLeg };
};

//draw the man
const drawMan = (count) => {
  let { head, body, leftArm, rightArm, leftLeg, rightLeg } = canvasCreator();
  switch (count) {
    case 1:
      head();
      break;
    case 2:
      body();
      break;
    case 3:
      leftArm();
      break;
    case 4:
      rightArm();
      break;
    case 5:
      leftLeg();
      break;
    case 6:
      rightLeg();
      break;
    default:
      break;
  }
};

//New Game
newGameButton.addEventListener("click", initializer);
window.onload = initializer;