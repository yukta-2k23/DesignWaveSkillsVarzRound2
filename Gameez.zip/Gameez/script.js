
  const buttons = document.querySelectorAll(".play-btn");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {

      window.location.href = "community.html";
    });
  });

  function handleReset() {
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('message').value = '';
  }
  
  function handleSend() {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
  
    if (!name || !email || !message) {
      alert('Please fill out all fields.');
      return;
    }
  
    // Corrected template literal
    alert(`Message sent!\n\nName: ${name}\nEmail: ${email}\nMessage: ${message}`);
  
    // Here you can replace with actual form submission logic (e.g., AJAX or Formspree)
  }
  
