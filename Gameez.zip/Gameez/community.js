window.communities = {
    'Minecraft': [],
    'Zelda': [],
    'Valorant': []
  };
  